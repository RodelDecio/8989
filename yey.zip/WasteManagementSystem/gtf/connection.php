<?php

$db=new	mysqli('localhost','root','','cmc');

?>